from asyncio import constants
from cgitb import text
from multiprocessing import connection
from re import L
from celery import shared_task
import requests
from celery import shared_task
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
from bs4 import BeautifulSoup
import aiohttp
import yfinance as yf
import asyncio
import csv
import datetime
import datetime as dt
import json
import logging
import threading
from webbrowser import get
import aiohttp
import lxml.html
import numpy as np
import pandas as pd
import requests
import websocket
import yfinance as yf
from bs4 import BeautifulSoup
from django.http import HttpResponse
from lxml.html.soupparser import fromstring
from asgiref.sync import sync_to_async
from .models import Industry
from datetime import date , timedelta
from .models import Industry, User, Wallet,Trade, Notification, HistoryTrades
from django.utils import timezone


channel_layer = get_channel_layer()


async def home():

    async def get_pokemon(session, url):
        async with session.get(url, headers = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36" }) as res:
            pokemon_data = await res.text()
            web_content = BeautifulSoup(pokemon_data, "lxml")
            for div in web_content.find_all("div", class_="D(ib) Mend(20px)"):
                return div.text
    
    txt = []
    actions = []
    pokemon_data = []
    summary = []
    index = ["BTC-USD", "ETH-USD" , "TSLA", "FB", "AMZN", "NFLX","NVDA","CL=F", "MGC=F", "NG=F"]

    async with aiohttp.ClientSession() as session:
        for x in index:
            url = "https://finance.yahoo.com/quote/" + str(x) + "?p=" + str(x) + "&.tsrc=fin-srch"
            actions.append(asyncio.create_task(get_pokemon(session, url)))

        pokemon_res = await asyncio.gather(*actions)
        for data in pokemon_res:
            newdata = data.split(" ")
            newdata1 = newdata[1].replace("As","")
            data = data.replace("-", " ")
            data = data.replace("+", " ")
            txt = data.split(" ")
            pokemon_data.append(txt[0])
            summary.append(newdata1)
    contextt = {"pokemon_data": pokemon_data, "summary": summary}
    return contextt


@shared_task()
def get_joke():
    name = ["BITCOIN", "ETHEREUM", "TESLA", "FACEBOOK", "AMAZON", "NETFLIX", "NVIDIA", "OIL","GOLD","NATGAS"]
    #updated_values = {'industry_name': name[counter], 'price':txt[0]}
    prices = asyncio.run(home())
    for i in range(0, len(name)):
        obj,created = Industry.objects.update_or_create(industry_name = name[i])
        
        xp = prices["pokemon_data"][i].split(",")
        xpp = ""
        for x in xp:
            xpp = xpp + x

        obj.price = xpp
        
        obj.save()
    joke1 = json.dumps(prices)

    async_to_sync(channel_layer.group_send)('jokes', {'type':'send_jokes', 'text':joke1})

@shared_task()
def checkPrice():

    current_trades = Trade.objects.all()
    xx = current_trades
    hh = []
    profit_loss = []
    for x in current_trades:
       
        if float(x.current_profit_loss) >= float(x.take_profit) or float(x.current_profit_loss) <= float(x.stop_loss):
            userwallet = Wallet.objects.get(user = x.Tuser)
            print("this is wallet of " + str(userwallet.user))
            print("Amount of wallet before delete = " + str(userwallet.amount))
            userwallet.amount = float(userwallet.amount) + float(x.trade_amount) + float(x.current_profit_loss)
            userwallet.save()
            print("Amount of wallet AFTER closing the deal is: " +str(userwallet.amount))
            xx = str(x).split("-")
            in1 = Industry.objects.get(industry_name = xx[1])
            u1 = User.objects.get(username = x.Tuser)
            curr1 = current_trades.filter(Tuser =  u1, indus_name = in1)

            for h in curr1:   
                userinfo = h.Tuser
                messageinfo = h.indus_name
                
                info = Notification(Nuser = userinfo, message = str(messageinfo) + " deal is Closed", messagetype = "notseen")
                info.save()
                
                price1 = Industry.objects.get(industry_name = in1)
                history = HistoryTrades(Tuser = u1, indus_name = in1, open_time = x.open_time ,close_time = timezone.now(), open_value = float(x.open_value), close_value = float(price1.price), units = float(x.units), TypeTrade = x.TypeTrade,trade_amount = float(x.trade_amount), take_profit = float(x.take_profit), stop_loss = float(x.stop_loss), closed_profit_loss = float(x.current_profit_loss))  
                history.save()

            try:
                record = Trade.objects.get(id = x.id)
                record.delete()
                print("Record deleted successfully!")
                break
            except:
                print("Record doesn't exists")
            
                

        if x.status == "active":
            pp = Industry.objects.get(industry_name = x.indus_name)
            if x.TypeTrade == "buy":
                profit = (float(x.units) * float(pp.price)) - float(x.trade_amount)
                x.current_profit_loss = profit
            elif x.TypeTrade == "sell":
                
                profit = float(x.trade_amount) - (float(x.units) * float(pp.price)) 
                xx.current_profit_loss = profit
            
            x.save()
            profit_loss.append(str(x.Tuser)+str(" ")+str(profit))

    profit_loss1 = json.dumps(profit_loss)
    async_to_sync(channel_layer.group_send)('profloss', {'type':'send_profit', 'text':profit_loss1})