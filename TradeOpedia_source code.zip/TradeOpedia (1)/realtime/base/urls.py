from django.urls import path
from django.urls.conf import include
from unicodedata import name
from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
urlpatterns = [
    
    path('', views.mainpage, name = "mainpage"),
    path('login/', views.loginPage, name = "login"),
    path('home/', views.home, name = "home"),
    path('logout/', views.logoutUser, name = "logout"),
    path('Portfolio/', views.Portfolio, name = "Portfolio"),
    path('Portfolio/History/', views.History, name = "History"),
    path('signup/', views.signupform, name = "signupform"),
    path('update/', views.updateUser, name = "updateUser"),
    path('watchlist/', views.watchlist, name = "watchlist" ),
    path('trade/<str:name>/',views.trade, name = "trade"),
    path('prediction', views.Prediction, name = "prediction"),
    path('reset_password/', auth_views.PasswordResetView.as_view(), name = "reset_password"),
    path('reset_password_sent/', auth_views.PasswordResetDoneView.as_view(), name = "password_reset_done"),
    path('rest/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name = "password_reset_confirm"),
    path('reset_password_complete/', auth_views.PasswordResetCompleteView.as_view(), name = "password_reset_complete"),
]
