import os 
from celery import Celery
from django.conf import settings
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'realtime.settings')

app = Celery('realtime')

app.config_from_object('django.conf:settings', namespace='CELERY')

app.autodiscover_tasks(settings.INSTALLED_APPS)

app.conf.beat_schedule = {
    'get_joke_3s': {
        'task': 'base.tasks.get_joke',
        'schedule': 8.0
    },

    'Profit/Loss': {
        'task': 'base.tasks.checkPrice',
        'schedule': 8.2
    }
}


@app.task(bind=True)
def debug_task(self):
    print(f'Request: {self.request!r}')